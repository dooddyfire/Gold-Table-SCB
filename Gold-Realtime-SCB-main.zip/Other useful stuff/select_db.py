import sqlite3 


print("AFTER UPDATE")
with sqlite3.connect("Gold.db") as con: 

    curr = con.cursor()

    sql_cmd = "SELECT * FROM Gold_Comp;"

    for row in curr.execute(sql_cmd).fetchall(): 
        print(row)