import sqlite3



with sqlite3.connect("Gold.db") as con: 

    curr = con.cursor()

    sql_cmd = """
    
    CREATE TABLE Gold_Comp(
        
        Name Text,
        BuyPrice Text,
        SellPrice Text,
        Time Text
    );
    
    """

    curr.execute(sql_cmd)
    con.commit()

    print("Create Table Successful")