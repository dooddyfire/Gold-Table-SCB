import sqlite3 
import json
import pprint
import websocket
from websocket import create_connection


with sqlite3.connect("Gold.db") as con: 

    curr = con.cursor()

    websocket.enableTrace(True)

    ws = create_connection('wss://www.sctgold.com/primepush/productPrice/100/ONLINE/A')

    result = ws.recv()
    data = json.loads(result)
    print(data)  

    name_lis = []
    buy_lis = []
    sell_lis = []
    time_lis = []
    for i in data['productPriceDTOs']:
        name_eng = i['productDTO']['nameEn']
        name_lis.append(name_eng)
        print("Name : ",name_eng)

        buy_price = i['buyPrice']
        buy_lis.append(buy_price)
        print("Buy : ",buy_price)

        sell_price = i['sellPrice']
        sell_lis.append(sell_price)
        print("Sell : ",sell_price)

        timex = data['priceTime_en']
        time_lis.append(timex)
        print("Time : ",timex)





    name_lis = ['Gold Spot', 'Silver Spot', 'GTA', 'THB', 'THB Offshore', 'Gold 96.5', 'Thai Gold 96.5% (g)', 'Gold 99.99', 'Gold 99.99 (g)', 'Gold 96.5 (B)', 'Gold 99.99 (B)', 'Gold 96.5 (OGO)', 'Gold 96.5 (OGB)', 'GoldSpot LBMA', 'Gold Small gram (B)', 'Gold Small Bar (B)', 'Gold 99.99 (IX)', 'Gold 965 (IX)', 'Convert Thai Gold (G)', 'gf10', 'GCDEC']


    sql_cmd = """
    
    UPDATE Gold_Comp SET BuyPrice=?,SellPrice=?,Time=? WHERE Name=?;
    """

    for x in range(len(name_lis)):
        curr.execute(sql_cmd,(name_lis[x],buy_lis[x],sell_lis[x],time_lis[x]))
    con.commit()

    print(name_lis)
    print(buy_lis)
    print(sell_lis)
    print(time_lis)

    print("Update Successful")