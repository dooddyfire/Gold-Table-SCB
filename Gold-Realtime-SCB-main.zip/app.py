from flask import Flask,render_template,jsonify
import json
import pprint
import websocket
from websocket import create_connection
import requests


import sqlite3 
import json

app = Flask(__name__)

@app.route("/")
def index():
    websocket.enableTrace(True)

    ws = create_connection('wss://www.sctgold.com/primepush/productPrice/100/ONLINE/A')

    result = ws.recv()
    #print('Result: {}'.format(result))

    #result = ws.recv()
    #print('Result: {}'.format(result))

    #ws.send(json.dumps([json.dumps({'msg': 'connect', 'version': '1', 'support': ['1', 'pre2', 'pre1']})]))
    #result = ws.recv()

    data = json.loads(result)  #new_data
    old_data = [] #old_data 17.00

    with sqlite3.connect("Gold.db") as con: 

        curr = con.cursor()
        
        sql_cmd = "SELECT * FROM Gold_Comp;"

        # ==== Old Data =====
        for row in curr.execute(sql_cmd).fetchall(): 
            if row[0] == 'GTA':
                old_data.append(row)
            elif row[0] == 'Gold 96.5':
                old_data.append(row)
            elif row[0] == 'Gold Small Bar (B)':
                old_data.append(row)
            elif row[0].strip() == 'Gold Small gram (B)':
                old_data.append(row)
            elif row[0].strip() == 'Gold 99.99':
                old_data.append(row)
            elif row[0].strip() == 'Thai Gold 96.5% (g)':
                old_data.append(row)
            elif row[0] == 'Gold Spot':
                old_data.append(row)
            elif row[0] == 'THB':
                old_data.append(row)


        #==== New Data ====
        name_lis = []
        buy_lis =  []
        sell_lis = []
        time_lis = []
        for i in data['productPriceDTOs']:
            name_eng = i['productDTO']['nameEn']
            name_lis.append(name_eng)
            print("Name : ",name_eng)

            buy_price = i['buyPrice']
            buy_lis.append(buy_price)
            print("Buy : ",buy_price)

            sell_price = i['sellPrice']
            sell_lis.append(sell_price)
            print("Sell : ",sell_price)

            timex = data['priceTime_en']
            time_lis.append(timex)
            print("Time : ",timex)    

        print("------- OLD DATA ----------")
        print(old_data)
        

        new_data = []

        change_result_lis = []
        change_price_lis = []
        sell_old_lis = []
        sell_new_lis = []
        new_name_lis = []

        for old_item in old_data: 
            for new_item_name in name_lis:
                print('Old Item 0 : ',old_item[0])
                print('Old Item : ',old_item)
                print(new_item_name)
                if old_item[0].strip() == new_item_name.strip() :
                    
                    new_item_name_real = new_item_name
                    new_name_index = name_lis.index(new_item_name)
                    sell_old = old_item[2]
                    sell_new = sell_lis[new_name_index]
                    
                    if float(sell_old) > float(sell_new):
                        result = "down"
                        change = abs(float(sell_old)-float(sell_new))
                    
                    elif float(sell_old) < float(sell_new):
                        result = "up"
                        change = abs(float(sell_old)-float(sell_new))
                    else:
                        result = " "
                        change = abs(float(sell_old)-float(sell_new))
                    
                    change_result_lis.append(result)
                    change_price_lis.append(int(change))
                    sell_old_lis.append(sell_old)
                    sell_new_lis.append(sell_new)
                    new_name_lis.append(new_item_name_real)

        print(new_name_lis)
        print("Change Result :")
        print(change_result_lis)
        


        return render_template('index.html',data=data,old_data=old_data,change_result_lis=change_result_lis
        ,change_price_lis=change_price_lis,sell_old_lis=sell_old_lis,sell_new_lis=sell_new_lis,new_name_lis=new_name_lis)




def get_price():

    websocket.enableTrace(True)

    ws = create_connection('wss://www.sctgold.com/primepush/productPrice/100/ONLINE/A')

    result = ws.recv()
    #print('Result: {}'.format(result))

    #result = ws.recv()
    #print('Result: {}'.format(result))

    #ws.send(json.dumps([json.dumps({'msg': 'connect', 'version': '1', 'support': ['1', 'pre2', 'pre1']})]))
    #result = ws.recv()

    data = json.loads(result)  #new_data
    old_data = [] #old_data 17.00

    with sqlite3.connect("Gold.db") as con: 

        curr = con.cursor()
        
        sql_cmd = "SELECT * FROM Gold_Comp;"

        # ==== Old Data =====
        for row in curr.execute(sql_cmd).fetchall(): 
            if row[0] == 'GTA':
                old_data.append(row)
            elif row[0] == 'Gold 96.5':
                old_data.append(row)
            elif row[0] == 'Gold Small Bar (B)':
                old_data.append(row)
            elif row[0].strip() == 'Gold Small gram (B)':
                old_data.append(row)
            elif row[0].strip() == 'Gold 99.99':
                old_data.append(row)
            elif row[0].strip() == 'Thai Gold 96.5% (g)':
                old_data.append(row)
            elif row[0] == 'Gold Spot':
                old_data.append(row)
            elif row[0] == 'THB':
                old_data.append(row)


        #==== New Data ====
        name_lis = []
        buy_lis =  []
        sell_lis = []
        time_lis = []
        for i in data['productPriceDTOs']:
            name_eng = i['productDTO']['nameEn']
            name_lis.append(name_eng)
            print("Name : ",name_eng)

            buy_price = i['buyPrice']
            buy_lis.append(buy_price)
            print("Buy : ",buy_price)

            sell_price = i['sellPrice']
            sell_lis.append(sell_price)
            print("Sell : ",sell_price)

            timex = data['priceTime_en']
            time_lis.append(timex)
            print("Time : ",timex)    

        print("------- OLD DATA ----------")
        print(old_data)
        

        new_data = []

        change_result_lis = []
        change_price_lis = []
        sell_old_lis = []
        sell_new_lis = []
        new_name_lis = []

        for old_item in old_data: 
            for new_item_name in name_lis:
                print('Old Item 0 : ',old_item[0])
                print('Old Item : ',old_item)
                print(new_item_name)
                if old_item[0].strip() == new_item_name.strip() :
                    
                    new_item_name_real = new_item_name
                    new_name_index = name_lis.index(new_item_name)
                    sell_old = old_item[2]
                    sell_new = sell_lis[new_name_index]
                    
                    if float(sell_old) > float(sell_new):
                        result = "down"
                        change = abs(float(sell_old)-float(sell_new))
                    
                    elif float(sell_old) < float(sell_new):
                        result = "up"
                        change = abs(float(sell_old)-float(sell_new))
                    else:
                        result = " "
                        change = abs(float(sell_old)-float(sell_new))
                    
                    change_result_lis.append(result)
                    change_price_lis.append(int(change))
                    sell_old_lis.append(sell_old)
                    sell_new_lis.append(sell_new)
                    new_name_lis.append(new_item_name_real)

        print(new_name_lis)
        print("Change Result :")
        print(change_result_lis)
        

    return data


def get_old_price():

    websocket.enableTrace(True)

    ws = create_connection('wss://www.sctgold.com/primepush/productPrice/100/ONLINE/A')

    result = ws.recv()
    #print('Result: {}'.format(result))

    #result = ws.recv()
    #print('Result: {}'.format(result))

    #ws.send(json.dumps([json.dumps({'msg': 'connect', 'version': '1', 'support': ['1', 'pre2', 'pre1']})]))
    #result = ws.recv()

    data = json.loads(result)  #new_data
    old_data = [] #old_data 17.00

    with sqlite3.connect("Gold.db") as con: 

        curr = con.cursor()
        
        sql_cmd = "SELECT * FROM Gold_Comp;"

        # ==== Old Data =====
        for row in curr.execute(sql_cmd).fetchall(): 
            if row[0] == 'GTA':
                old_data.append(row)
            elif row[0] == 'Gold 96.5':
                old_data.append(row)
            elif row[0] == 'Gold Small Bar (B)':
                old_data.append(row)
            elif row[0].strip() == 'Gold Small gram (B)':
                old_data.append(row)
            elif row[0].strip() == 'Gold 99.99':
                old_data.append(row)
            elif row[0].strip() == 'Thai Gold 96.5% (g)':
                old_data.append(row)
            elif row[0] == 'Gold Spot':
                old_data.append(row)
            elif row[0] == 'THB':
                old_data.append(row)


        #==== New Data ====
        name_lis = []
        buy_lis =  []
        sell_lis = []
        time_lis = []
        for i in data['productPriceDTOs']:
            name_eng = i['productDTO']['nameEn']
            name_lis.append(name_eng)
            print("Name : ",name_eng)

            buy_price = i['buyPrice']
            buy_lis.append(buy_price)
            print("Buy : ",buy_price)

            sell_price = i['sellPrice']
            sell_lis.append(sell_price)
            print("Sell : ",sell_price)

            timex = data['priceTime_en']
            time_lis.append(timex)
            print("Time : ",timex)    

        print("------- OLD DATA ----------")
        print(old_data)
        

        new_data = []

        change_result_lis = []
        change_price_lis = []
        sell_old_lis = []
        sell_new_lis = []
        new_name_lis = []

        for old_item in old_data: 
            for new_item_name in name_lis:
                print('Old Item 0 : ',old_item[0])
                print('Old Item : ',old_item)
                print(new_item_name)
                if old_item[0].strip() == new_item_name.strip() :
                    
                    new_item_name_real = new_item_name
                    new_name_index = name_lis.index(new_item_name)
                    sell_old = old_item[2]
                    sell_new = sell_lis[new_name_index]
                    
                    if float(sell_old) > float(sell_new):
                        result = "down"
                        change = abs(float(sell_old)-float(sell_new))
                    
                    elif float(sell_old) < float(sell_new):
                        result = "up"
                        change = abs(float(sell_old)-float(sell_new))
                    else:
                        result = " "
                        change = abs(float(sell_old)-float(sell_new))
                    
                    change_result_lis.append(result)
                    change_price_lis.append(int(change))
                    sell_old_lis.append(sell_old)
                    sell_new_lis.append(sell_new)
                    new_name_lis.append(new_item_name_real)

        print(new_name_lis)
        print("Change Result :")
        print(change_result_lis)
        

    return change_price_lis







def stamp_db():
    websocket.enableTrace(True)

    ws = create_connection('wss://www.sctgold.com/primepush/productPrice/100/ONLINE/A')

    result = ws.recv()
    #print('Result: {}'.format(result))

    #result = ws.recv()
    #print('Result: {}'.format(result))

    #ws.send(json.dumps([json.dumps({'msg': 'connect', 'version': '1', 'support': ['1', 'pre2', 'pre1']})]))
    #result = ws.recv()
    data = json.loads(result)  
    

def scheduleTask():
    with sqlite3.connect("Gold.db") as con: 

        curr = con.cursor()

        websocket.enableTrace(True)

        ws = create_connection('wss://www.sctgold.com/primepush/productPrice/100/ONLINE/A')

        result = ws.recv()
        data = json.loads(result)
        print(data)  

        name_lis = []
        buy_lis = []
        sell_lis = []
        time_lis = []
        for i in data['productPriceDTOs']:
            name_eng = i['productDTO']['nameEn']
            name_lis.append(name_eng)
            print("Name : ",name_eng)

            buy_price = i['buyPrice']
            buy_lis.append(buy_price)
            print("Buy : ",buy_price)

            sell_price = i['sellPrice']
            sell_lis.append(sell_price)
            print("Sell : ",sell_price)

            timex = data['priceTime_en']
            time_lis.append(timex)
            print("Time : ",timex)

        sql_cmd = """
        
        INSERT INTO Gold_Comp VALUES(?,?,?,?);
        
        """

        
        curr.execute("DELETE FROM Gold_Comp;")
        for x in range(len(name_lis)):
            curr.execute(sql_cmd,(name_lis[x],buy_lis[x],sell_lis[x],time_lis[x]))
        con.commit()

        print("Insert Successful")

if __name__ == '__main__':

       app.run(debug=False,host='45.150.128.232',port=8000)
       #app.run(debug=False,host='localhost',port=8000)
   