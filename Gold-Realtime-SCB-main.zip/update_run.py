import pprint
import websocket
from websocket import create_connection
import requests
import sqlite3 
import json 
import schedule
import time

def job():
    with sqlite3.connect("Gold.db") as con: 

        curr = con.cursor()

        websocket.enableTrace(True)

        ws = create_connection('wss://www.sctgold.com/primepush/productPrice/100/ONLINE/A')

        result = ws.recv()
        data = json.loads(result)
        print(data)  

        name_lis = []
        buy_lis = []
        sell_lis = []
        time_lis = []
        for i in data['productPriceDTOs']:
            name_eng = i['productDTO']['nameEn']
            name_lis.append(name_eng)
            print("Name : ",name_eng)

            buy_price = i['buyPrice']
            buy_lis.append(buy_price)
            print("Buy : ",buy_price)

            sell_price = i['sellPrice']
            sell_lis.append(sell_price)
            print("Sell : ",sell_price)

            timex = data['priceTime_en']
            time_lis.append(timex)
            print("Time : ",timex)

        sql_cmd = """
        
        INSERT INTO Gold_Comp VALUES(?,?,?,?);
        
        """

        
        curr.execute("DELETE FROM Gold_Comp;")
        for x in range(len(name_lis)):
            curr.execute(sql_cmd,(name_lis[x],buy_lis[x],sell_lis[x],time_lis[x]))
        con.commit()

        print("Insert Successful")

schedule.every(30).seconds.do(job)
while True:
    schedule.run_pending()
    time.sleep(1)
